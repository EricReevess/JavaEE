eclipse(javaee版本)
#tomcat7.0
#sqlyog
#mysql

